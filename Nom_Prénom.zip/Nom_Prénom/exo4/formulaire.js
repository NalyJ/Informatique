
// pour stocker l'image cliquée
var image_choisie = null;

// affiche le message d'erreur 'msg'
// dans l'élément prévu à cet effet
function erreur(msg) {
	
}

// stocke l'élément HTML 'image'
// dans la variable image_choisie
function choisir(image) {
	
}

// Si le nom ou le prénom n'a pas été fourni
// ou si l'avatar n'a pas été choisi (autrement dit
// si aucune des images n'a été cliquée), affiche une
// erreur dans l'emplacement adéquat. Sinon, affiche le
// message récapitulatif de bienvenue et l'avatar
// dans les éléments adéquats
function valider() {
	
}
