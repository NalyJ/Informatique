<?php

	$galerie = [];
	
	$file = file("galerie.csv",FILE_IGNORE_NEW_LINES);
	


?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <title>Exercice 3</title>
        <link href="galerie.css" type="text/css" rel="stylesheet">
    </head>
    <body>
    	<h1>Exercice 3 : galerie</h1>
    	<h2>Cliquez sur une image pour voir la fiche du personnage</h2>
    	<div class="galerie">
<?php



?>
		</div>
    </body>
</html>
