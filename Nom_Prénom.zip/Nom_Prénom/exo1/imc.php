<?php

?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <title>Exercice 1</title>
        <link href="imc.css" type="text/css" rel="stylesheet">
    </head>
    <body>
        <h1>Exercice 1 : IMC</h1>
        <h3>Votre IMC est de <?php    ?></h3>
        <h3>Interprétation : <?php    ?></h3>
    </body>
</html>
