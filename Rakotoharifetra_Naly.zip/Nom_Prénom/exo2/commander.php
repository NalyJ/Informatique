<?php

	$menu = [ "hamburger" => [ "nom" => "Burger", "prix" => 5 ],
			  "fries" => [ "nom" => "Frites", "prix" => 2.5 ],
			  "ketchup" => [ "nom" => "Kectchup", "prix" => 0.5 ],
			  "sunday" => [ "nom" => "Sunday", "prix" => 3 ],
			  "soda" => [ "nom" => "Soda", "prix" => 2 ] ];

	$total = 0;
	function commande($keyval){

		$r="<ul>";
		foreach ($keyval as $key => $value) {
			$nombre = $_GET[$key];
			foreach ($value as $key1 => $value1) {


			$r.= "<li>$nombre x {$value1}</li>";
			if ($key1 == " prix"){
				$total+=$value1*$nombre;
				}
			}
		}
		$r.="</ul>";
		return $r;
	}
?>
<!DOCTYPE html>
<html lang="fr">
	<head>
		<meta charset="utf-8">
		<title>Exercice 2</title>
		<link href="menu.css" type="text/css" rel="stylesheet">
	</head>
	<body>
		<h1>Votre commande</h1>
		<ul>
<?php

echo commande($menu);
echo $total;

?>
		</ul>
<?php
	if ( $total == 0 )
	{
		echo "<h2>Vous n'avez rien commandé !</h2>\n";
	}
	else
	{
		echo "<h2>Total : $total &euro;</h2>\n";
	}
?>
	</body>
</html>
