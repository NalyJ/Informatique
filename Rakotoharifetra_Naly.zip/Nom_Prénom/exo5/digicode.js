
var lecode = "1234"; // le code secret !
var essai = "";      // le code tapé par l'utilisateur
var fermee = true;   // si 'fermee' est vrai alors la porte est fermée

// affiche le message 'msg' dans
// l'élément prévu à cet effet et rend
// cet élément visible
function message(msg) {
	
}

// cache l'élément contenant les messages
function cacher() {
	
}

// Si la porte est déjà ouverte, affiche le message
// "la porte est ouverte", sinon ajoute le caractère
// 'c' à la variable essai
function ajouter_un_chiffre(c) {
	
}

// Si la porte est déjà ouverte, affiche le message
// "la porte est ouverte", sinon réinitialise la
// variable 'essai'
function annuler() {
			
}

// Si la porte est déjà ouverte, affiche le message 
// "la porte est ouverte".
// Si l'utilisateur a tapé un code correct, affiche
// l'image de la porte ouverte, sinon affiche
// le message "code erroné"
function entrer() {
		
}
