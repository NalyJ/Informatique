<?php

	$galerie = [];
	
	$file = file("galerie.csv",FILE_IGNORE_NEW_LINES);
	

	
?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <title>Exercice 3</title>
        <link href="galerie.css" type="text/css" rel="stylesheet">
    </head>
    <body>
    	<h1>Exercice 3 : galerie</h1>
    	<div class="info">
<?php



?>
			<div class="last"><a href="galerie.php">Retour à la galerie</a></div>
		</div>
    </body>
</html>

