window.onload = function () {


var valimage;

var dimension;



function select(){

let src = this.src;

let tokens("");

let tokens = explode("/");





}

function start(){



let link = document.location.href="puzzle.php?puzzle="<?= basename($puzzle) ?>">"

}



}
