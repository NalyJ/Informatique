<?php

	function extract_letter($s) {
		$a = explode(".",basename($s));
		$a = explode("-",$a[0]);
		return $a[1];
	}

	$x = parseInt($_GET[]); // A remplir
	$y = parseInt($_GET[]); // A remplir
	$puzzle = $_GET["puzzle"];
	$array = glob("puzzle/$puzzle/*.jpeg");
	$title = file_get_contents("puzzle/$puzzle/title.txt");
?>
<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
    <title>TP 2 - Exo 4</title>
	<meta name="author" content="">
	<link type="text/css" rel="stylesheet" href="../css/tp2.css" />
    <link type="text/css" rel="stylesheet" href="puzzle.css" />
    <script type="text/javascript" src="puzzle.js"></script>
  </head>

<body>
	<h1>TP 2 - Exo 4</h1>
	<hr>

<h2><?= $title ?></h2>

<img id="image" src="puzzle/<?= $puzzle ?>/image.jpg" />

<div id="puzzle">
	<div>
<?php
	for ( $i = 0; $i < count($array)-1; $i++ ) {
		if ( $i > 0 && $i % $x == 0 ) {
?>
	</div><div>
<?php
		}
?>
      <img name="<?= $i ?>" src="<?= $array[$i] ?>" alt="<?= $i ?>" />
<?php
	}
?>
<img name="<?= count($array)-1 ?>" src="images/trou.jpeg" />
	</div>
</div>

<div id="result">Bravo vous avez terminé le puzzle !!</div>

</body>
</html>

<script>
window.onload = function () {

	let taille = x*y; // A remplir!!!!!!!!
	let not_finished = true; // Est-ce que la partie est terminée
	let trou= document.querySelector("trou"); // On récupère le document image trou
	let placeTrou = taille; // Emplacement du trou
	mixer();

	function mixer() { // Mélange le puzzle : A remplir !
		return null;
	}

	function nearTrou() { // revoie "est-ce que l'image est proche du trou ?", change l'emplacement du trou si oui
		let numCase = parseInt(this.alt);
		if (placeTrou -1 == numCase || placeTrou +1 == numCase || placeTrou+x == numCase || placeTrou-x == numCase) {
			placeTrou = numCase;
			return true;
		}
		return false;
	}

	// traîte le clic sur une image
	function click_on() {
		if (not_finished) { // Si la partie n'est pas finie
				if (this.nearTrou()) { // Si l'image est assez proche du trou
					let image = document.querySelector(toString(placeTrou)); // On récupère la source de l'image qui montrait le trou
					image.src = this.src;
					this.src = trou.src; // On remplace la source de l'image par celle du trou
					let vartemp = image.alt;
					image.alt = this.alt;
					this.alt = vartemp;
				}
			}
			if (is_finished()) {
				let result = document.querySelector("#result");
				result.style.visibility = "visible";
				not_finished = false;
			}
		}
	}


	// teste si le puzzle est terminé
	function is_finished() {
		let s = "";
		let rep = "";
		let images = document.querySelector("#puzzle").querySelectorAll("");
		for (let i = 0; i < images.length; i++)
			s += images[i].name;
			rep += i;
		return s == rep;
	}

	// ici, il faut relier la fonction "clic_on" à l'évènement "onclick"
	// sur toutes les images contenues dans l'élément d'id "puzzle"
	let imgs = document.querySelector("#puzzle").querySelectorAll("");
	for ( let i = 0; i < imgs.length; i++ )
		imgs[i].onclick = click_on;
};

</script>
