<?php

	function extract_letter($s) {
		$a = explode(".",basename($s));
		$a = explode("-",$a[0]);
		return $a[1];
	}

	$x = $_GET["dimension"]; // A remplir
	$x = explode("x",$x);
	$y = $x[1];
	$x = $x[0];
	$puzzle = $_GET["image"];
	$array = glob("$puzzle/*.jpeg");
	$title = file_get_contents("$puzzle/title.txt");
?>
<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
    <title>TP 2 - Exo 4</title>
	<meta name="author" content="">
	<link type="text/css" rel="stylesheet" href="../css/tp2.css" />
    <link type="text/css" rel="stylesheet" href="puzzle.css" />
    <script type="text/javascript" src="puzzle.js"></script>
  </head>

<body>
	<h1>TP 2 - Exo 4</h1>
	<hr>

<h2><?= $title ?></h2>

<img id="image" src="<?= $puzzle ?>/image.jpg" />

<div id="puzzle">
	<div>
<?php
	for ( $i = 0; $i < count($array)-1; $i++ ) {
		if ( $i > 0 && $i % $x == 0 ) {
?>
	</div><div>
<?php
		}
?>
      <img id="part" name="<?= $i ?>" src="<?= $array[$i] ?>" alt="<?= $i ?>" />
<?php
	}
?>
<img name="<?= count($array)-1 ?>" src="trou.jpg" />
	</div>
</div>

<div id="result">Bravo vous avez terminé le puzzle !!</div>

</body>
</html>
