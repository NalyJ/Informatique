window.onload = function () {
	let imgs = document.getElementsByTagName("puzzle");
	alert(imgs);
	let taille = imgs.length; // On va essayer d'obtenir taille sans prendre x et y, juste en récupérant les infos directement sur la page
	let not_finished = true; // Est-ce que la partie est terminée
	let trou= document.querySelector("trou"); // On récupère le document image trou
	let placeTrou = taille; // Emplacement du trou
	mixer();
	alert(taille);

	function mixer() { // Mélange le puzzle : A remplir !
		return null;
	}

	function nearTrou() { // renvoie "est-ce que l'image est proche du trou ?", change l'emplacement du trou si oui
		let numCase = parseInt(this.alt);
		alert(numCase);
		if (placeTrou -1 == numCase || placeTrou +1 == numCase || placeTrou+x == numCase || placeTrou-x == numCase) {
			return true;
		}
		return false;
	}


	function click_on() {
		if (not_finished) { // Si la partie n'est pas finie
				if (this.nearTrou()) { // Si l'image est assez proche du trou
					let image = document.querySelector(toString(placeTrou)); // On récupère l'image qui montrait le trou
					placeTrou = numCase;
					image.src = this.src;
					this.src = trou.src; // On remplace la source de l'image par celle du trou
					let vartemp = image.alt;
					image.alt = this.alt;
					this.alt = vartemp;
				}
			}
			if (is_finished()) {
				//let result = document.querySelector("#result");
				//result.style.visibility = "visible";
				not_finished = false;
			}
		}



	// teste si le puzzle est terminé
	function is_finished() {
		let s = "";
		let rep = "";
		let images = document.querySelector("#puzzle").querySelectorAll("image");
		for (let i = 0; i < images.length; i++)
			s += images[i].name;
			rep += i;
		return s == rep;
	}
	// ici, il faut relier la fonction "clic_on" à l'évènement "onclick"
	// sur toutes les images contenues dans l'élément d'id "puzzle"
	for ( let i = 0; i < imgs.length; i++ ) {
		imgs[i].onclick = click_on;
};
}
