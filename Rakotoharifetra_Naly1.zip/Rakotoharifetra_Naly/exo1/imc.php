<?php

function interprétation( $imc ) {

  //si la moyenne est inférieur à 6
  if ($imc <= 40)

  //retourne l'appreciation suivante
    return "Obésité massive";

//si la moyenne est comprise entre 6 et 10
  if (($imc >= 35) && ($imc<40))
  //retourne l'appreciation suivante
    return "obésité severe";

//si la moyenne est comprise entre 10 et 13
  if (($imc >= 30) && ($imc<35))

  //retourne l'appreciation suivante
    return "obésité modéré";

//si la moyenne est comprise entre 13 et 16
  if (($imc >= 25) && ($imc<30))

  //retourne l'appreciation suivante
    return "surpoids";

//si la moyenne est comprise entre 16 et 19
  if (($imc>= 18.5) && ($imc<25))

  //retourne l'appreciation suivante
    return "corpulence normale";

    if (($imc>= 16.5) && ($imc<18.5))

    //retourne l'appreciation suivante
      return "maigreur";

//si la moyenne est superieur à 19
  if (($imc<16.5))

  //retourne l'appreciation suivante
    return "dénutrition";
}
function calcul($poids,$taille){
  $resultat=$poids/($taille*$taille);
  $resultat=round($resultat);
  return $resultat;
}
$poids=$_GET["poids"];
$taille=$_GET["taille"];
$imc=calcul($poids,$taille);

?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <title>Exercice 1</title>
        <link href="imc.css" type="text/css" rel="stylesheet">
    </head>
    <body>
        <h1>Exercice 1 : IMC</h1>
        <h3>Votre IMC est de <?php  echo calcul($poids,$taille)  ?></h3>
        <h3>Interprétation : <?php echo interprétation($imc)   ?></h3>
    </body>
</html>
