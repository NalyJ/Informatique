window.onload = function () {

	// le nombre de clics effectués
	var clics = 0;

	// le nombre de smiley or découverts
	var smiley_or = 0;

	// affiche les gains dans l'élément adéquat
	// en fonction du nombre de smiley or découverts
	function alerte_finale() {
		
	}

	// Traîte le clic effectué sur une image
	// (autrement dit sur l'élément 'this')
	function cliquer() {
        
	}

    //// Accrochage du JavaScript aux éléments HTML
    //// ( à compléter ! )

	

};
