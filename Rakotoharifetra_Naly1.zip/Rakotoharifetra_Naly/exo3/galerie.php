<?php

	$galerie = [];
	$i=1;
	$file = file("galerie.csv",FILE_IGNORE_NEW_LINES);
	foreach ($file as $line) {
		$galerie["avenger$i"]=explode(",", $line);
		$i++;
	}


?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <title>Exercice 3</title>
        <link href="galerie.css" type="text/css" rel="stylesheet">
    </head>
    <body>
    	<h1>Exercice 3 : galerie</h1>
    	<h2>Cliquez sur une image pour voir la fiche du personnage</h2>
    	<div class="galerie">
<?php
$r="";
foreach ( $galerie as $key => $val ) {
	$r .= "   <a href="personnage.php?id=$key"><img src="images/{$val[0]}" title="{$val[2]}"></a>";

return $r;



?>
		</div>
    </body>
</html>
